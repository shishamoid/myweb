ng build
echo "ng built!!!"
python main.py
